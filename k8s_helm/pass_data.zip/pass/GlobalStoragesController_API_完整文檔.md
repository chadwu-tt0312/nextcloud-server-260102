# Nextcloud GlobalStoragesController API 完整文檔

## 概述

`GlobalStoragesController` 是 Nextcloud External Storage 的 REST API 控制器，用於管理系統級（Global）的外部儲存掛載點。

**Base URL:** `/apps/files_external/globalstorages`

**認證方式:**
- Basic Authentication（管理員帳號）
- Header: `OCS-APIRequest: true`
- Header: `Content-Type: application/json`（POST/PUT 時）

---

## API 端點列表

### 1. GET `/apps/files_external/globalstorages`
**方法:** `index()`

**功能:** 取得所有系統級外部儲存掛載點清單

**參數:** 無

**回應:**
- **成功 (200 OK):** 返回掛載點陣列
- **格式:** JSON 陣列，每個元素包含完整的掛載點配置

**範例:**
```bash
curl -X GET "http://localhost:8085/apps/files_external/globalstorages" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Accept: application/json"
```

---

### 2. GET `/apps/files_external/globalstorages/{id}`
**方法:** `show(int $id)`

**功能:** 取得指定 ID 的系統級外部儲存掛載點

**參數:**
| 參數 | 類型 | 位置 | 說明 |
|------|------|------|------|
| `id` | int | URL Path | 掛載點 ID |

**回應:**
- **成功 (200 OK):** 返回掛載點詳細資訊
- **失敗 (404 Not Found):** `{"message": "Storage with ID \"{id}\" not found"}`

**範例:**
```bash
curl -X GET "http://localhost:8085/apps/files_external/globalstorages/1" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true"
```

---

### 3. POST `/apps/files_external/globalstorages`
**方法:** `create(...)`

**功能:** 建立新的系統級外部儲存掛載點

**認證要求:** 需要密碼確認（`#[PasswordConfirmationRequired(strict: true)]`）

**請求參數 (JSON Body):**

| 參數名稱 | 類型 | 必填 | 說明 | 範例值 |
|---------|------|------|------|--------|
| `mountPoint` | string | ✅ | 掛載點路徑（必須以 `/` 開頭） | `"/minio-DEPT_SMG_ARC1"` |
| `backend` | string | ✅ | Backend 識別碼 | `"amazons3"` |
| `authMechanism` | string | ✅ | 認證機制識別碼 | `"amazons3::accesskey"` |
| `backendOptions` | object | ✅ | Backend 特定選項（見下方詳述） | `{...}` |
| `mountOptions` | object | 選填 | 掛載選項 | `{}` |
| `applicableUsers` | array | 選填 | 適用使用者清單（空陣列表示所有使用者） | `[]` |
| `applicableGroups` | array | 選填 | 適用群組清單 | `[]` |
| `priority` | int | 選填 | 優先級 | `100` |

**backendOptions（AmazonS3 範例）:**

| 參數名稱 | 類型 | 必填 | 說明 | 範例值 |
|---------|------|------|------|--------|
| `bucket` | string | ✅ | S3 Bucket 名稱 | `"dep-smg-arc1-filespace"` |
| `hostname` | string | 選填 | S3 主機位址 | `"192.168.31.180"` |
| `port` | string | 選填 | 連接埠 | `"9000"` |
| `region` | string | 選填 | AWS Region | `"us-east-1"` |
| `use_ssl` | boolean | 選填 | 啟用 SSL（預設: `true`） | `false` |
| `use_path_style` | boolean | ✅ | 啟用 Path Style（**必需，無預設值**） | `true` |
| **`legacy_auth`** | boolean | ✅ | V2 Legacy 認證 | `false` |
| **`useMultipartCopy`** | boolean | ✅ | 啟用 multipart copy（預設: `true`） | `true` |
| `sse_c_key` | string | 選填 | SSE-C 加密金鑰 | `""` |
| `key` | string | ✅ | Access Key（認證機制參數） | `"ZEPNGTC059NIHD4KHYVW"` |
| `secret` | string | ✅ | Secret Key（認證機制參數） | `"xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"` |

**重要注意事項:**
- `use_path_style` 是 **BOOLEAN 類型且非可選**（沒有 `FLAG_OPTIONAL`，也沒有預設值），**必須明確提供**
- `key` 和 `secret` 屬於認證機制參數，但放在 `backendOptions` 中
- `bucket` 是唯一**必填的 backend 參數**

**回應:**
- **成功 (201 Created):** 返回建立的掛載點完整資訊
- **失敗 (422 Unprocessable Entity):**
  - `{"message": "Unsatisfied backend parameters"}` - Backend 參數驗證失敗
  - `{"message": "Unsatisfied authentication mechanism parameters"}` - 認證機制參數驗證失敗
  - `{"message": "Invalid mount point"}` - 掛載點無效
  - `{"message": "Invalid backend or authentication mechanism class"}` - Backend 或認證機制無效
  - `{"message": "Not permitted to use backend \"{backend}\""}` - 不允許使用該 backend
  - `{"message": "Not permitted to use authentication mechanism \"{auth}\""}` - 不允許使用該認證機制
- **失敗 (403 Forbidden):** `{"message": "Forbidden to manage local mounts"}` - 不允許管理 local 掛載（如果 `backend === 'local'` 且系統設定禁止）

**範例:**
```bash
curl -X POST "http://localhost:8085/apps/files_external/globalstorages" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-DEPT_SMG_ARC1",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "dep-smg-arc1-filespace",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ZEPNGTC059NIHD4KHYVW",
      "secret": "xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": [],
    "priority": 100
  }'
```

---

### 4. PUT `/apps/files_external/globalstorages/{id}`
**方法:** `update(int $id, ...)`

**功能:** 更新指定 ID 的系統級外部儲存掛載點

**認證要求:** 需要密碼確認（`#[PasswordConfirmationRequired(strict: true)]`）

**請求參數 (URL Path + JSON Body):**

| 參數名稱 | 類型 | 位置 | 必填 | 說明 |
|---------|------|------|------|------|
| `id` | int | URL Path | ✅ | 掛載點 ID |
| `mountPoint` | string | JSON Body | ✅ | 掛載點路徑 |
| `backend` | string | JSON Body | ✅ | Backend 識別碼 |
| `authMechanism` | string | JSON Body | ✅ | 認證機制識別碼 |
| `backendOptions` | object | JSON Body | ✅ | Backend 特定選項 |
| `mountOptions` | object | JSON Body | 選填 | 掛載選項 |
| `applicableUsers` | array | JSON Body | 選填 | 適用使用者清單 |
| `applicableGroups` | array | JSON Body | 選填 | 適用群組清單 |
| `priority` | int | JSON Body | 選填 | 優先級 |

**回應:**
- **成功 (200 OK):** 返回更新後的掛載點完整資訊
- **失敗 (404 Not Found):** `{"message": "Storage with ID \"{id}\" not found"}`
- **失敗 (422 Unprocessable Entity):** 同 POST 的驗證錯誤

**範例:**
```bash
curl -X PUT "http://localhost:8085/apps/files_external/globalstorages/1" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-DEPT_SMG_ARC1",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "dep-smg-arc1-filespace-updated",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ZEPNGTC059NIHD4KHYVW",
      "secret": "xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": [],
    "priority": 100
  }'
```

---

### 5. DELETE `/apps/files_external/globalstorages/{id}`
**方法:** `destroy(int $id)`

**功能:** 刪除指定 ID 的系統級外部儲存掛載點

**認證要求:** 需要密碼確認（`#[PasswordConfirmationRequired(strict: true)]`）

**請求參數:**

| 參數名稱 | 類型 | 位置 | 必填 | 說明 |
|---------|------|------|------|------|
| `id` | int | URL Path | ✅ | 掛載點 ID |

**回應:**
- **成功 (204 No Content):** 空回應
- **失敗 (404 Not Found):** `{"message": "Storage with ID \"{id}\" not found"}`

**範例:**
```bash
curl -X DELETE "http://localhost:8085/apps/files_external/globalstorages/1" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true"
```

---

## 驗證流程

當建立或更新掛載點時，Nextcloud 會執行以下驗證：

1. **掛載點驗證:**
   - 掛載點不能為空字串
   - 如果 `backend === 'local'` 且系統設定禁止，返回 403

2. **Backend 驗證:**
   - 檢查 backend 是否存在且可用
   - 檢查 backend 是否允許在當前環境使用
   - 驗證 `backendOptions` 中的參數是否符合 backend 定義
   - **關鍵:** `use_path_style` 必須提供（BOOLEAN，非可選）

3. **認證機制驗證:**
   - 檢查認證機制是否支援該 backend
   - 檢查認證機制是否允許在當前環境使用
   - 驗證認證機制參數（如 `key`, `secret`）

4. **參數驗證:**
   - 所有**非可選參數**必須提供且不能為空
   - BOOLEAN 類型參數必須是 `true`/`false` 或字串 `"true"`/`"false"`

---

## 常見錯誤與解決方案

### 錯誤: "Unsatisfied backend parameters"

**可能原因:**
1. 缺少必需參數（如 `bucket`）
2. `use_path_style` 未提供（**這是常見原因**）
3. 參數類型錯誤（如 BOOLEAN 參數傳遞了非 boolean 值）

**解決方案:**
- 確保 `use_path_style` 明確設為 `true` 或 `false`
- 檢查所有必需參數是否提供
- 確認參數類型正確

### 錯誤: "Unsatisfied authentication mechanism parameters"

**可能原因:**
1. 缺少 `key` 或 `secret`
2. `key` 或 `secret` 為空

**解決方案:**
- 確保 `key` 和 `secret` 都有值且不為空

---

## 參數類型說明

### BOOLEAN 參數
- 接受值: `true`, `false`（JSON boolean）
- 也接受字串: `"true"`, `"false"`（會自動轉換）
- **不接受:** `null`, `""`, `0`, `1`

### STRING 參數
- 必須是非空字串（除非標記為可選）
- 空字串 `""` 會被視為無效值（對於非可選參數）

### 陣列參數
- `applicableUsers`: 字串陣列，空陣列 `[]` 表示所有使用者
- `applicableGroups`: 字串陣列

---

## 完整請求範例（AmazonS3）

```bash
curl -X POST "http://localhost:8085/apps/files_external/globalstorages" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-DEPT_SMG_ARC1",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "dep-smg-arc1-filespace",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ZEPNGTC059NIHD4KHYVW",
      "secret": "xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": [],
    "priority": 100
  }'
```

---

## 參考資料

- **控制器檔案:** `apps/files_external/lib/Controller/GlobalStoragesController.php`
- **基礎控制器:** `apps/files_external/lib/Controller/StoragesController.php`
- **路由配置:** `apps/files_external/appinfo/routes.php`
- **AmazonS3 Backend:** `apps/files_external/lib/Lib/Backend/AmazonS3.php`
- **AccessKey 認證:** `apps/files_external/lib/Lib/Auth/AmazonS3/AccessKey.php`
