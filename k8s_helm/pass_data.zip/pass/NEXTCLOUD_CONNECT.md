# Nextcloud 連接指南

## 快速連接

根據您的配置，Nextcloud 使用 **NodePort** 方式暴露服務。

### 方法 1：使用腳本（推薦）

```bash
bash k8s_helm/connect-nextcloud.sh
```

腳本會自動顯示：
- Service 類型和端口
- 訪問 URL
- 登入憑證
- Pod 狀態

### 方法 2：直接訪問

根據您的配置（`values.yaml`）：
- **NodePort**: `31805`
- **Service Port**: `8080`
- **Trusted Domain**: `nextcloud.kube.home`

#### 步驟 1：取得節點 IP

```bash
# 取得節點 IP
NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')

# 或使用第一個可用的地址
NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[0].address}')

echo "節點 IP: $NODE_IP"
```

#### 步驟 2：訪問 Nextcloud

```bash
# 在瀏覽器訪問
http://<NODE_IP>:31805

# 例如，如果節點 IP 是 192.168.31.180
http://192.168.31.180:31805
```

#### 步驟 3：取得登入憑證

```bash
# 取得 username
kubectl get secret nextcloud -n default -o jsonpath='{.data.nextcloud-username}' | base64 -d

# 取得 password
kubectl get secret nextcloud -n default -o jsonpath='{.data.nextcloud-password}' | base64 -d
```

### 方法 3：使用 Port-Forward（如果 NodePort 無法訪問）

```bash
# 開啟 port-forward
kubectl port-forward -n default svc/nextcloud 8080:8080

# 然後在瀏覽器訪問
http://localhost:8080
```

## 驗證連接

### 檢查 Service 狀態

```bash
kubectl get svc nextcloud -n default
```

預期輸出：
```
NAME        TYPE       CLUSTER-IP    EXTERNAL-IP   PORT(S)          AGE
nextcloud   NodePort   10.96.x.x     <none>        8080:31805/TCP   XXm
```

### 檢查 Pod 狀態

```bash
kubectl get pod -n default -l app.kubernetes.io/name=nextcloud
```

預期輸出：
```
NAME                        READY   STATUS    RESTARTS   AGE
nextcloud-6df4d44bf6-4zzlw  1/1     Running   0          XXm
```

### 測試連接

```bash
# 使用 curl 測試
curl -I http://<NODE_IP>:31805

# 或使用 pod IP 直接測試
POD_IP=$(kubectl get pod -n default -l app.kubernetes.io/name=nextcloud -o jsonpath='{.items[0].status.podIP}')
curl -I http://$POD_IP:80
```

## 常見問題

### 問題 1：無法訪問 NodePort

**可能原因：**
- 防火牆阻擋了端口 31805
- 節點 IP 無法從您的機器訪問
- Service 配置錯誤

**解決方案：**
1. 檢查防火牆規則
2. 使用 port-forward 作為替代方案
3. 檢查 Service 配置：`kubectl describe svc nextcloud -n default`

### 問題 2：Trusted Domain 錯誤

如果看到 "Access through untrusted domain" 錯誤：

**解決方案：**
1. 確認訪問的域名/IP 在 `NEXTCLOUD_TRUSTED_DOMAINS` 中
2. 當前配置的 trusted domain：`nextcloud.kube.home`
3. 如果需要添加新的域名，更新 `values.yaml` 中的 `nextcloud.host` 或 `nextcloud.trustedDomains`

### 問題 3：Pod 無法啟動

**檢查步驟：**
```bash
# 查看 Pod 詳細資訊
kubectl describe pod <pod-name> -n default

# 查看 Pod 日誌
kubectl logs <pod-name> -n default

# 查看 Init Container 日誌
kubectl logs <pod-name> -n default -c mariadb-isalive
```

### 問題 4：資料庫連接失敗

如果 Init Container `mariadb-isalive` 一直等待：

```bash
# 檢查 MariaDB Service
kubectl get svc nextcloud-mariadb -n default

# 檢查 MariaDB Pod
kubectl get pod -n default -l app.kubernetes.io/name=mariadb

# 測試資料庫連接
kubectl run -it --rm mariadb-client --image=bitnami/mariadb:latest --restart=Never -- \
  mysql -h nextcloud-mariadb -u root -p
```

## 配置 Ingress（可選）

如果您想使用域名訪問而不是 IP+Port，可以啟用 Ingress：

### 1. 更新 values.yaml

```yaml
ingress:
  enabled: true
  className: nginx  # 或您使用的 ingress controller
  annotations:
    nginx.ingress.kubernetes.io/proxy-body-size: "4G"
  hosts:
    - host: nextcloud.kube.home
      paths:
        - path: /
          pathType: Prefix
  tls: []  # 可選：配置 TLS
```

### 2. 更新 Helm Release

```bash
helm upgrade nextcloud ./k8s_helm/nextcloud -f ./k8s_helm/nextcloud/values.yaml
```

### 3. 配置 DNS

確保 `nextcloud.kube.home` 解析到您的 Ingress Controller IP。

## 安全建議

1. **使用 HTTPS**：生產環境建議配置 TLS
2. **限制訪問**：使用 NetworkPolicy 限制 Pod 之間的網路訪問
3. **定期備份**：確保 PVC 有定期備份
4. **更新密碼**：首次登入後立即更改預設密碼

## 相關命令

```bash
# 查看所有 Nextcloud 相關資源
kubectl get all -n default -l app.kubernetes.io/name=nextcloud

# 查看 ConfigMap
kubectl get configmap -n default -l app.kubernetes.io/name=nextcloud

# 查看 Secret
kubectl get secret -n default -l app.kubernetes.io/name=nextcloud

# 查看 PVC
kubectl get pvc -n default -l app.kubernetes.io/name=nextcloud

# 進入 Pod 執行命令
kubectl exec -it <pod-name> -n default -- bash
```
