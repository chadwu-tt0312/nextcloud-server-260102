---
name: 建立 Nextcloud 外部儲存空間同步程式
overview: 建立一個 Python 程式，透過 Nextcloud API 取得現有的 amazons3 外部儲存空間，比對 mounts.json 中的 bucket，並自動建立不存在的項目。
todos:
  - id: "1"
    content: 建立 create_external_storage.py 程式框架，包含命令列參數解析和基本結構
    status: pending
  - id: "2"
    content: 實作 GET API 呼叫功能，取得所有外部儲存空間並過濾出 amazons3 backend
    status: pending
  - id: "3"
    content: 實作資料格式轉換函數，將 mounts.json 格式轉換為 API 格式
    status: pending
  - id: "4"
    content: 實作 POST API 呼叫功能，建立新的外部儲存空間
    status: pending
  - id: "5"
    content: 實作主要處理邏輯：比對 bucket 列表並建立不存在的項目
    status: pending
  - id: "6"
    content: 加入錯誤處理、日誌記錄和統計資訊輸出
    status: pending
isProject: false
---

# 建立 Nextcloud 外部儲存空間同步程式

## 目標

建立一個 Python 程式，功能為：

1. 使用 Nextcloud API 取得所有 `backend="amazons3"` 的外部儲存空間，提取 bucket 列表
2. 讀取 `tools/mounts.json` 並比對每筆資料的 bucket 是否存在
3. 對於不存在的 bucket，呼叫 API 建立新的外部儲存空間
4. 確認回傳狀態碼為 201 表示建立成功

## 檔案結構

### 新檔案

- `tools/create_external_storage.py` - 主要程式檔案

## 實作細節

### 1. API 呼叫功能

參考 `ref/api-nextcloud.http` 中的 API 定義：

- **GET 所有外部儲存空間**：
  - 端點：`GET {ENV_NEXTCLOUD_URL}/apps/files_external/globalstorages` 
  - 認證：Basic Auth（從 `.env` 檔案中取得 `ENV_NEXTCLOUD_USER` 和 `ENV_NEXTCLOUD_PASSWORD`）
  - Header：`OCS-APIRequest: true`, `Content-Type: application/json`
  - 實作方式：使用 `httpx.Client` 的 `get()` 方法，透過 `auth` 參數傳遞 Basic Auth
  - 回傳格式：JSON 物件，key 為 ID，value 包含 `backend` 和 `backendOptions`，當 `backend="amazons3"` 時取得 `backendOptions.bucket`

- **POST 建立外部儲存空間**：
  - 端點：`POST {ENV_NEXTCLOUD_URL}/apps/files_external/globalstorages`
  - 認證：Basic Auth
  - Header：`OCS-APIRequest: true`, `Content-Type: application/json`
  - Body：JSON 格式，包含 `mountPoint`, `backend`, `authMechanism`, `backendOptions` 等
  - 實作方式：使用 `httpx.Client` 的 `post()` 方法，透過 `json` 參數傳遞 JSON 資料
  - 成功回傳：HTTP 201 狀態碼

### 2. 資料格式轉換

`mounts.json` 格式需要轉換為 API 格式：

**mounts.json 格式**：

```json
{
  "mount_point": "/minio-DEPT_SMG_ARC1",
  "authentication_type": "amazons3::accesskey",
  "configuration": {
    "bucket": "dept-smg-arc1-filespace",
    "hostname": "192.168.31.180",
    "port": "9000",
    "region": "us-east-1",
    "use_ssl": false,
    "use_path_style": true,
    "key": "...",
    "secret": "..."
  }
}
```

**API 格式**：

```json
{
  "mountPoint": "/minio-DEPT_SMG_ARC1",
  "backend": "amazons3",
  "authMechanism": "amazons3::accesskey",
  "backendOptions": {
    "bucket": "dept-smg-arc1-filespace",
    "hostname": "192.168.31.180",
    "port": "9000",
    "region": "us-east-1",
    "use_ssl": false,
    "use_path_style": true,
    "legacy_auth": false,
    "useMultipartCopy": true,
    "key": "...",
    "secret": "..."
  },
  "mountOptions": {},
  "applicableUsers": [],
  "applicableGroups": []
}
```

### 3. 程式流程

1. 使用 `load_dotenv()` 載入環境變數，讀取 `ENV_NEXTCLOUD_URL`, `ENV_NEXTCLOUD_USER`, `ENV_NEXTCLOUD_PASSWORD`
2. 使用 `httpx.Client(timeout=60.0)` 建立 HTTP 客戶端
3. 呼叫 GET API 取得所有外部儲存空間（使用 `client.get()` 並傳遞 Basic Auth）
4. 解析 JSON 回應，過濾出 `backend="amazons3"` 的項目，提取 `backendOptions.bucket` 列表存入 `bucket_lst`（轉為小寫以便比對）
5. 讀取 `tools/mounts.json`（使用 `pathlib.Path` 處理路徑）
6. 迴圈處理每筆資料：

   - 檢查 `configuration.bucket`（轉小寫）是否存在於 `bucket_lst`
   - 如果不存在，轉換格式並呼叫 POST API 建立（使用 `client.post()`）
   - 使用 `response.raise_for_status()` 檢查狀態碼，確認回傳狀態碼為 201

7. 輸出處理結果統計（總筆數、已存在、新增成功、新增失敗）

### 4. 技術實作

參考 `pass/file_trans.py` 的實作方式：

- 使用 `httpx` 庫進行 HTTP 請求（而非 `requests`）
  - 使用 `httpx.Client(timeout=60.0)` 作為 context manager
  - 使用 `response.raise_for_status()` 檢查 HTTP 狀態碼
  - 處理 `httpx.TimeoutException` 和 `httpx.HTTPStatusError` 異常
  - 使用 Basic Auth：`httpx.BasicAuth(username, password)` 或透過 `auth` 參數傳遞
- 使用 `json` 處理 JSON 資料
- 使用 `argparse` 處理命令列參數
- 使用 `logging` 記錄執行過程
- 從環境變數讀取 Nextcloud URL 和認證資訊（使用 `python-dotenv` 的 `load_dotenv()` 和 `os.getenv()`）
- 使用 `pathlib.Path` 處理檔案路徑

### 5. 錯誤處理

參考 `pass/file_trans.py` 的錯誤處理方式：

- 使用 `try-except` 捕捉 `httpx.TimeoutException`：記錄逾時錯誤並繼續處理
- 使用 `try-except` 捕捉 `httpx.HTTPStatusError`：記錄 HTTP 狀態碼錯誤（如 401, 403, 404 等）
- 使用 `try-except` 捕捉一般 `Exception`：記錄其他未預期的錯誤
- API 請求失敗時記錄錯誤並繼續處理下一筆（不中斷整個流程）
- 驗證回傳狀態碼，非 201 時記錄警告
- 處理 JSON 解析錯誤（`response.json()` 可能拋出 `json.JSONDecodeError`）
- 處理檔案讀取錯誤（`FileNotFoundError`, `IOError` 等）

### 6. 輸出資訊

- 顯示處理進度
- 統計：總筆數、已存在、新增成功、新增失敗
- 記錄詳細的錯誤訊息

## 檔案位置

- 程式檔案：`tools/ccreate_external_storage.py`
- 參考檔案：
  - `ref/api-nextcloud.http`（API 格式參考）
  - `pass/file_trans.py`（HTTP 請求實作參考）
- 資料檔案：`tools/mounts.json`（輸入資料）
- 環境變數檔案：`.env`（包含 `ENV_NEXTCLOUD_URL`, `ENV_NEXTCLOUD_USER`, `ENV_NEXTCLOUD_PASSWORD`）

## 依賴套件

- `httpx` - HTTP 請求（參考 `pass/file_trans.py` 的實作方式）
- `python-dotenv` - 環境變數讀取（從 `.env` 檔案讀取 `ENV_NEXTCLOUD_URL`, `ENV_NEXTCLOUD_USER`, `ENV_NEXTCLOUD_PASSWORD`）

## 命令列參數

- `--mounts-file` - mounts.json 檔案路徑（預設：`tools/mounts.json`）
- `--dry-run` - 預覽模式，不實際建立，純粹列出項目並記錄（選用）

## 注意事項

- API 認證資訊建議從環境變數讀取，避免硬編碼
- bucket 固定轉小寫
- 需要處理 `legacy_auth` 和 `useMultipartCopy` 等預設值，**mounts.json** 檔案沒有的欄位直接套用 **API 格式**的預設值