#!/bin/bash
# 測試 Nextcloud External Storage API - 建立單一掛載點
# 修正後的 curl 命令

# 從 .env 讀取配置（或直接設定）
MINIO_BUCKET="dep-smg-arc1-filespace"
MINIO_HOST="192.168.31.180"
MINIO_PORT="9000"
MINIO_REGION="us-east-1"
ACCESS_KEY="ZEPNGTC059NIHD4KHYVW"
SECRET_KEY="xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"

# Nextcloud 設定
NEXTCLOUD_URL="http://localhost:8085"
ADMIN_USER="admin"
ADMIN_PASS="password123"

# 注意：根據 Nextcloud API，可能需要確保所有參數都存在
# 嘗試不同的參數組合來找出問題

echo "測試 1: 使用完整參數（包含 priority）"
RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" -X POST "${NEXTCLOUD_URL}/apps/files_external/globalstorages" \
  -u "${ADMIN_USER}:${ADMIN_PASS}" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d "{
    \"mountPoint\": \"/minio-DEPT_SMG_ARC1\",
    \"backend\": \"amazons3\",
    \"authMechanism\": \"amazons3::accesskey\",
    \"backendOptions\": {
      \"bucket\": \"${MINIO_BUCKET}\",
      \"hostname\": \"${MINIO_HOST}\",
      \"port\": \"${MINIO_PORT}\",
      \"region\": \"${MINIO_REGION}\",
      \"use_ssl\": false,
      \"use_path_style\": true,
      \"legacy_auth\": false,
      \"useMultipartCopy\": true,
      \"key\": \"${ACCESS_KEY}\",
      \"secret\": \"${SECRET_KEY}\"
    },
    \"mountOptions\": {},
    \"applicableUsers\": [],
    \"applicableGroups\": [],
    \"priority\": 100
  }")

HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
BODY=$(echo "$RESPONSE" | sed '/HTTP_CODE/d')

echo "HTTP Status: $HTTP_CODE"
echo "Response: $BODY"
echo ""

# 如果失敗，嘗試只使用必需參數
if [ "$HTTP_CODE" != "201" ] && [ "$HTTP_CODE" != "200" ]; then
  echo "測試 2: 只使用必需參數（bucket, key, secret）+ priority"
  RESPONSE2=$(curl -s -w "\nHTTP_CODE:%{http_code}" -X POST "${NEXTCLOUD_URL}/apps/files_external/globalstorages" \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    -H "OCS-APIRequest: true" \
    -H "Content-Type: application/json" \
    -d "{
      \"mountPoint\": \"/minio-DEPT_SMG_ARC1\",
      \"backend\": \"amazons3\",
      \"authMechanism\": \"amazons3::accesskey\",
      \"backendOptions\": {
        \"bucket\": \"${MINIO_BUCKET}\",
        \"legacy_auth\": false,
        \"useMultipartCopy\": true,
        \"key\": \"${ACCESS_KEY}\",
        \"secret\": \"${SECRET_KEY}\"
      },
      \"mountOptions\": {},
      \"applicableUsers\": [],
      \"applicableGroups\": [],
      \"priority\": 100
    }")
  
  HTTP_CODE2=$(echo "$RESPONSE2" | grep "HTTP_CODE" | cut -d: -f2)
  BODY2=$(echo "$RESPONSE2" | sed '/HTTP_CODE/d')
  
  echo "HTTP Status: $HTTP_CODE2"
  echo "Response: $BODY2"
  echo ""
fi

# 如果還是失敗，嘗試檢查現有的掛載點格式
if [ "$HTTP_CODE" != "201" ] && [ "$HTTP_CODE" != "200" ] && [ "$HTTP_CODE2" != "201" ] && [ "$HTTP_CODE2" != "200" ]; then
  echo "測試 3: 檢查現有掛載點（GET）"
  GET_RESPONSE=$(curl -s -X GET "${NEXTCLOUD_URL}/apps/files_external/globalstorages" \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    -H "OCS-APIRequest: true" \
    -H "Accept: application/json")
  
  if command -v jq &> /dev/null; then
    echo "$GET_RESPONSE" | jq '.'
  else
    echo "$GET_RESPONSE"
    echo ""
    echo "提示：安裝 jq 可獲得更好的 JSON 格式化輸出"
  fi
  echo ""
  
  # 測試 4: 檢查 backend 和 authMechanism 是否正確
  echo "測試 4: 檢查可用的 backend 和 authMechanism"
  echo "（這需要查看 Nextcloud 的 API 文檔或源碼）"
  echo ""
  
  # 測試 5: 嘗試使用不同的參數格式
  echo "測試 5: 嘗試使用字串格式的 port（而非數字）"
  RESPONSE3=$(curl -s -w "\nHTTP_CODE:%{http_code}" -X POST "${NEXTCLOUD_URL}/apps/files_external/globalstorages" \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    -H "OCS-APIRequest: true" \
    -H "Content-Type: application/json" \
    -d "{
      \"mountPoint\": \"/minio-DEPT_SMG_ARC1\",
      \"backend\": \"amazons3\",
      \"authMechanism\": \"amazons3::accesskey\",
      \"backendOptions\": {
        \"bucket\": \"${MINIO_BUCKET}\",
        \"hostname\": \"${MINIO_HOST}\",
        \"port\": \"${MINIO_PORT}\",
        \"region\": \"${MINIO_REGION}\",
        \"use_ssl\": \"false\",
        \"use_path_style\": \"true\",
        \"legacy_auth\": false,
        \"useMultipartCopy\": true,
        \"key\": \"${ACCESS_KEY}\",
        \"secret\": \"${SECRET_KEY}\"
      },
      \"mountOptions\": {},
      \"applicableUsers\": [],
      \"applicableGroups\": [],
      \"priority\": 100
    }")
  
  HTTP_CODE3=$(echo "$RESPONSE3" | grep "HTTP_CODE" | cut -d: -f2)
  BODY3=$(echo "$RESPONSE3" | sed '/HTTP_CODE/d')
  
  echo "HTTP Status: $HTTP_CODE3"
  echo "Response: $BODY3"
  echo ""
fi
