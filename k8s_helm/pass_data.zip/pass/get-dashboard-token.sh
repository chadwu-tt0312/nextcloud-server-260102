#!/bin/bash

# Kubernetes Dashboard Token 取得腳本
# 支援多種方式取得 token

set -e

echo "=========================================="
echo "Kubernetes Dashboard Token 取得工具"
echo "=========================================="
echo ""

# 方法 1: 使用 default namespace 的 default service account
echo "方法 1: 使用 default namespace 的 default service account"
echo "---------------------------------------------------"

# 檢查 secret 是否存在
SECRET_NAME=$(kubectl get serviceaccount default -n default -o jsonpath='{.secrets[0].name}' 2>/dev/null || echo "")

if [ -z "$SECRET_NAME" ]; then
    echo "⚠️  default service account 沒有自動創建 secret"
    echo "正在創建 token secret..."
    
    # 創建 token secret（Kubernetes 1.24+ 需要手動創建）
    kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: default-token
  namespace: default
  annotations:
    kubernetes.io/service-account.name: default
type: kubernetes.io/service-account-token
EOF
    
    # 等待 secret 創建
    echo "等待 secret 創建..."
    sleep 3
    SECRET_NAME="default-token"
fi

# 取得 token
TOKEN=$(kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.token}' | base64 -d 2>/dev/null || kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.token}' | base64 -D 2>/dev/null || echo "")

if [ -n "$TOKEN" ]; then
    echo "✅ Token 取得成功："
    echo "$TOKEN"
    echo ""
    echo "將 token 儲存到環境變數 \$DASHBOARD_TOKEN"
    export DASHBOARD_TOKEN="$TOKEN"
    echo ""
else
    echo "❌ 無法取得 token"
    echo ""
fi

# 方法 2: 使用 kubernetes-dashboard namespace 的 service account
echo "方法 2: 使用 kubernetes-dashboard service account"
echo "---------------------------------------------------"

# 創建 admin service account（如果不存在）
kubectl apply -f - <<EOF 2>/dev/null || true
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kubernetes-dashboard
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kubernetes-dashboard
EOF

echo "等待 service account 創建..."
sleep 3

# 取得 admin-user 的 token
DASHBOARD_SECRET=$(kubectl get serviceaccount admin-user -n kubernetes-dashboard -o jsonpath='{.secrets[0].name}' 2>/dev/null || echo "")

if [ -z "$DASHBOARD_SECRET" ]; then
    echo "⚠️  創建 token secret..."
    kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: admin-user-token
  namespace: kubernetes-dashboard
  annotations:
    kubernetes.io/service-account.name: admin-user
type: kubernetes.io/service-account-token
EOF
    sleep 3
    DASHBOARD_SECRET="admin-user-token"
fi

DASHBOARD_TOKEN=$(kubectl get secret "$DASHBOARD_SECRET" -n kubernetes-dashboard -o jsonpath='{.data.token}' | base64 -d 2>/dev/null || kubectl get secret "$DASHBOARD_SECRET" -n kubernetes-dashboard -o jsonpath='{.data.token}' | base64 -D 2>/dev/null || echo "")

if [ -n "$DASHBOARD_TOKEN" ]; then
    echo "✅ Dashboard Token 取得成功："
    echo "$DASHBOARD_TOKEN"
    echo ""
    echo "將 token 儲存到環境變數 \$DASHBOARD_ADMIN_TOKEN"
    export DASHBOARD_ADMIN_TOKEN="$DASHBOARD_TOKEN"
    echo ""
else
    echo "❌ 無法取得 dashboard token"
    echo ""
fi

# 方法 3: 使用 kubectl create token（Kubernetes 1.24+）
echo "方法 3: 使用 kubectl create token（推薦，Kubernetes 1.24+）"
echo "---------------------------------------------------"

if kubectl create token admin-user -n kubernetes-dashboard --duration=8760h > /dev/null 2>&1; then
    K8S_TOKEN=$(kubectl create token admin-user -n kubernetes-dashboard --duration=8760h)
    echo "✅ 使用 kubectl create token 取得成功："
    echo "$K8S_TOKEN"
    echo ""
    echo "將 token 儲存到環境變數 \$K8S_DASHBOARD_TOKEN"
    export K8S_DASHBOARD_TOKEN="$K8S_TOKEN"
    echo ""
else
    echo "⚠️  kubectl create token 不可用（可能需要 Kubernetes 1.24+）"
    echo ""
fi

# 顯示 Dashboard 訪問資訊
echo "=========================================="
echo "Dashboard 訪問資訊"
echo "=========================================="
echo ""

# 取得 Dashboard service 資訊
DASHBOARD_SVC=$(kubectl get svc kubernetes-dashboard -n kubernetes-dashboard -o jsonpath='{.spec.type}' 2>/dev/null || echo "ClusterIP")

if [ "$DASHBOARD_SVC" = "ClusterIP" ]; then
    echo "📌 Dashboard 使用 ClusterIP，需要 port-forward："
    echo ""
    echo "執行以下命令開啟 port-forward："
    echo "  kubectl port-forward -n kubernetes-dashboard service/kubernetes-dashboard 8443:443"
    echo ""
    echo "然後在瀏覽器訪問："
    echo "  https://localhost:8443"
    echo ""
    echo "或使用以下命令自動開啟 port-forward（背景執行）："
    echo "  kubectl port-forward -n kubernetes-dashboard service/kubernetes-dashboard 8443:443 &"
    echo ""
else
    NODE_PORT=$(kubectl get svc kubernetes-dashboard -n kubernetes-dashboard -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null || echo "")
    if [ -n "$NODE_PORT" ]; then
        echo "📌 Dashboard 使用 NodePort：$NODE_PORT"
        echo ""
        echo "在瀏覽器訪問："
        echo "  https://<node-ip>:$NODE_PORT"
        echo ""
    fi
fi

echo "使用以下任一 token 登入："
echo "  - \$DASHBOARD_TOKEN (default service account)"
echo "  - \$DASHBOARD_ADMIN_TOKEN (admin-user service account)"
echo "  - \$K8S_DASHBOARD_TOKEN (kubectl create token)"
echo ""

# 顯示可用的 token
if [ -n "$K8S_DASHBOARD_TOKEN" ]; then
    echo "推薦使用：\$K8S_DASHBOARD_TOKEN"
    echo "$K8S_DASHBOARD_TOKEN"
elif [ -n "$DASHBOARD_ADMIN_TOKEN" ]; then
    echo "推薦使用：\$DASHBOARD_ADMIN_TOKEN"
    echo "$DASHBOARD_ADMIN_TOKEN"
elif [ -n "$DASHBOARD_TOKEN" ]; then
    echo "使用：\$DASHBOARD_TOKEN"
    echo "$DASHBOARD_TOKEN"
fi
