# Nextcloud External Storage API 完整指南

## 目錄
1. [External Storage Support API 研究](#1-external-storage-support-api-研究)
2. [如何呼叫 External Storage Support API](#2-如何呼叫-external-storage-support-api)
3. [在 Docker/K8s 環境執行 occ 命令](#3-在-dockerk8s-環境執行-occ-命令)

---

## 1. External Storage Support API 研究

### 1.1 可用方法概述

Nextcloud 提供三種方式來建立 External Storage 掛載點：

| 方法 | 適用場景 | 效率 | 推薦度 |
|------|----------|------|--------|
| **OCC 指令** `files_external:import` | JSON 批次匯入 | ⭐⭐⭐⭐⭐ **最高** | ✅ **最推薦** |
| **OCC 指令** `files_external:create` | 單筆建立，適合腳本呼叫 | ⭐⭐⭐ 中等 | 適合少量 |
| **REST API** `/apps/files_external/globalstorages` | HTTP POST 建立 | ⭐⭐⭐ 中等 | 適合整合 |

### 1.2 推薦方案：`files_external:import` + JSON 批次匯入

對於需要建立 **10,000 個目錄**的場景，強烈建議使用 `files_external:import` 指令搭配 JSON 批次匯入。

**優點：**
- ✅ 單一指令即可批次匯入大量掛載點
- ✅ 支援 `--dry` 預覽模式，可先驗證 JSON 格式
- ✅ 支援從 stdin 讀取（`-`），適合管道操作
- ✅ 執行效率最高

### 1.3 JSON 格式結構

#### 完整範例

```json
[
  {
    "mount_id": 1,
    "mount_point": "/minio-user00001",
    "storage": "\\OCA\\Files_External\\Lib\\Storage\\AmazonS3",
    "authentication_type": "amazons3::accesskey",
    "configuration": {
      "bucket": "minio-user00001-filespace",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ACCESS_KEY_00001",
      "secret": "SECRET_KEY_00001"
    },
    "options": {},
    "applicable_users": [],
    "applicable_groups": []
  }
]
```

#### 欄位說明

| 欄位 | 類型 | 必填 | 說明 |
|------|------|------|------|
| `mount_id` | integer | ✅ | 掛載 ID（用於識別，可重複） |
| `mount_point` | string | ✅ | 掛載點路徑（如 `/minio-user00001`） |
| `storage` | string | ✅ | Storage Backend 類別名稱 |
| `authentication_type` | string | ✅ | 認證機制識別碼 |
| `configuration` | object | ✅ | Backend 設定參數 |
| `options` | object | ❌ | 掛載選項（通常為空物件） |
| `applicable_users` | array | ❌ | 適用使用者清單（空陣列 = 所有使用者） |
| `applicable_groups` | array | ❌ | 適用群組清單 |

#### S3 Backend 設定參數

| 參數名稱 | 類型 | 必填 | 說明 | 範例值 |
|----------|------|------|------|--------|
| `bucket` | string | ✅ | S3 Bucket 名稱 | `minio-user00001-filespace` |
| `hostname` | string | ❌ | S3 主機位址 | `192.168.31.180` |
| `port` | string | ❌ | 連接埠 | `9000` |
| `region` | string | ❌ | AWS Region | `us-east-1` |
| `use_ssl` | boolean | ❌ | 啟用 SSL | `false` |
| `use_path_style` | boolean | ❌ | 啟用 Path Style | `true` |
| `key` | string | ✅ | Access Key | `VOR9QID1QHPSMX...` |
| `secret` | string | ✅ | Secret Key | `**********` |

### 1.4 使用 Python 工具產生 JSON

專案中已提供 `tools/generate_external_storage.py` 工具，可自動產生 JSON 設定檔。

#### 基本用法

```bash
# 從 CSV 讀取使用者清單
python generate_external_storage.py --csv users.csv --output mounts.json

# 從 import-accounts.csv 格式讀取
python generate_external_storage.py --import-csv import-accounts.csv --output mounts.json
```

#### CSV 格式範例（users.csv）

```csv
user_id,bucket_name,access_key,secret_key
minio-user00001,minio-user00001-filespace,ACCESS_KEY_00001,SECRET_KEY_00001
minio-user00002,minio-user00002-filespace,ACCESS_KEY_00002,SECRET_KEY_00002
```

#### 產生 10,000 個目錄的範例

```python
# 使用 Python 產生 10,000 筆資料
import json

mounts = []
for i in range(1, 10001):
    user_id = f"minio-user{i:05d}"
    mounts.append({
        "mount_id": i,
        "mount_point": f"/{user_id}",
        "storage": "\\OCA\\Files_External\\Lib\\Storage\\AmazonS3",
        "authentication_type": "amazons3::accesskey",
        "configuration": {
            "bucket": f"{user_id}-filespace",
            "hostname": "192.168.31.180",
            "port": "9000",
            "region": "us-east-1",
            "use_ssl": False,
            "use_path_style": True,
            "key": f"ACCESS_KEY_{i:05d}",
            "secret": f"SECRET_KEY_{i:05d}"
        },
        "options": {},
        "applicable_users": [],
        "applicable_groups": []
    })

with open("mounts.json", "w", encoding="utf-8") as f:
    json.dump(mounts, f, indent=2, ensure_ascii=False)
```

---

## 2. 如何呼叫 External Storage Support API

### 2.1 REST API 端點

Nextcloud 提供 REST API 來管理 External Storage，主要端點如下：

#### 2.1.1 建立 Global Storage（系統掛載）

**Endpoint:** `POST /apps/files_external/globalstorages`

**認證方式：**
- Basic Auth（管理員帳號）
- Header: `OCS-APIRequest: true`

**Request Body 範例：**

```json
{
  "mountPoint": "/minio-user00001",
  "backend": "amazons3",
  "authMechanism": "amazons3::accesskey",
  "backendOptions": {
    "bucket": "minio-user00001-filespace",
    "hostname": "192.168.31.180",
    "port": "9000",
    "region": "us-east-1",
    "use_ssl": false,
    "use_path_style": true,
    "key": "ACCESS_KEY_00001",
    "secret": "SECRET_KEY_00001"
  },
  "mountOptions": {},
  "applicableUsers": [],
  "applicableGroups": []
}
```

**cURL 範例：**

```bash
curl -X POST \
  "https://nextcloud.example.com/apps/files_external/globalstorages" \
  -u "admin:password" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-user00001",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "minio-user00001-filespace",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ACCESS_KEY_00001",
      "secret": "SECRET_KEY_00001"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": []
  }'
```

**Python 範例：**

```python
import requests

url = "https://nextcloud.example.com/apps/files_external/globalstorages"
auth = ("admin", "password")
headers = {
    "OCS-APIRequest": "true",
    "Content-Type": "application/json"
}
data = {
    "mountPoint": "/minio-user00001",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
        "bucket": "minio-user00001-filespace",
        "hostname": "192.168.31.180",
        "port": "9000",
        "region": "us-east-1",
        "use_ssl": False,
        "use_path_style": True,
        "key": "ACCESS_KEY_00001",
        "secret": "SECRET_KEY_00001"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": []
}

response = requests.post(url, auth=auth, headers=headers, json=data)
print(response.status_code)
print(response.json())
```

#### 2.1.2 查詢所有 Global Storages

**Endpoint:** `GET /apps/files_external/globalstorages`

```bash
curl -X GET \
  "https://nextcloud.example.com/apps/files_external/globalstorages" \
  -u "admin:password" \
  -H "OCS-APIRequest: true"
```

#### 2.1.3 查詢特定 Storage

**Endpoint:** `GET /apps/files_external/globalstorages/{id}`

```bash
curl -X GET \
  "https://nextcloud.example.com/apps/files_external/globalstorages/1" \
  -u "admin:password" \
  -H "OCS-APIRequest: true"
```

#### 2.1.4 更新 Storage

**Endpoint:** `PUT /apps/files_external/globalstorages/{id}`

```bash
curl -X PUT \
  "https://nextcloud.example.com/apps/files_external/globalstorages/1" \
  -u "admin:password" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-user00001",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "minio-user00001-filespace-updated",
      ...
    }
  }'
```

#### 2.1.5 刪除 Storage

**Endpoint:** `DELETE /apps/files_external/globalstorages/{id}`

```bash
curl -X DELETE \
  "https://nextcloud.example.com/apps/files_external/globalstorages/1" \
  -u "admin:password" \
  -H "OCS-APIRequest: true"
```

### 2.2 OCS API（使用者掛載點查詢）

**Endpoint:** `GET /ocs/v2.php/apps/files_external/api/v1/mounts`

此 API 用於查詢目前使用者可見的掛載點。

```bash
curl -X GET \
  "https://nextcloud.example.com/ocs/v2.php/apps/files_external/api/v1/mounts" \
  -u "user:password" \
  -H "OCS-APIRequest: true"
```

### 2.3 API 回應格式

#### 成功回應（建立/更新）

```json
{
  "id": 1,
  "mountPoint": "/minio-user00001",
  "backend": "amazons3",
  "authMechanism": "amazons3::accesskey",
  "backendOptions": {
    "bucket": "minio-user00001-filespace",
    ...
  },
  "mountOptions": {},
  "applicableUsers": [],
  "applicableGroups": [],
  "priority": 100,
  "status": 0,
  "statusMessage": "",
  "type": "system",
  "userProvided": false
}
```

#### 錯誤回應

```json
{
  "message": "Invalid mount point"
}
```

---

## 3. 在 Docker/K8s 環境執行 occ 命令

### 3.1 Docker 環境

#### 方法一：使用 docker exec（推薦）

```bash
# 1. 確認 Nextcloud 容器名稱
docker ps | grep nextcloud

# 2. 將 mounts.json 複製到容器內
docker cp mounts.json nextcloud-container:/tmp/mounts.json

# 3. 執行 import 指令（預覽模式）
docker exec -u www-data nextcloud-container \
  php occ files_external:import --dry /tmp/mounts.json

# 4. 正式匯入
docker exec -u www-data nextcloud-container \
  php occ files_external:import /tmp/mounts.json

# 5. 清理臨時檔案
docker exec nextcloud-container rm /tmp/mounts.json
```

#### 方法二：使用 stdin（適合小檔案）

```bash
# 從本地檔案透過 stdin 傳入
cat mounts.json | docker exec -i -u www-data nextcloud-container \
  php occ files_external:import -
```

#### 方法三：使用 Volume Mount

```bash
# 1. 在 docker-compose.yml 中掛載目錄
# volumes:
#   - ./mounts.json:/tmp/mounts.json:ro

# 2. 執行 import
docker exec -u www-data nextcloud-container \
  php occ files_external:import /tmp/mounts.json
```

#### 完整範例腳本

```bash
#!/bin/bash
# import_external_storage.sh

CONTAINER_NAME="nextcloud-container"
MOUNTS_FILE="mounts.json"

# 檢查容器是否存在
if ! docker ps --format "{{.Names}}" | grep -q "^${CONTAINER_NAME}$"; then
    echo "❌ 容器 ${CONTAINER_NAME} 不存在或未運行"
    exit 1
fi

# 複製檔案到容器
echo "📋 複製 ${MOUNTS_FILE} 到容器..."
docker cp "${MOUNTS_FILE}" "${CONTAINER_NAME}:/tmp/mounts.json"

# 預覽模式
echo "🔍 預覽模式（dry-run）..."
docker exec -u www-data "${CONTAINER_NAME}" \
  php occ files_external:import --dry /tmp/mounts.json

# 確認是否繼續
read -p "是否繼續匯入？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ 已取消"
    docker exec "${CONTAINER_NAME}" rm /tmp/mounts.json
    exit 1
fi

# 正式匯入
echo "📥 開始匯入..."
docker exec -u www-data "${CONTAINER_NAME}" \
  php occ files_external:import /tmp/mounts.json

# 清理
docker exec "${CONTAINER_NAME}" rm /tmp/mounts.json

echo "✅ 匯入完成"
```

### 3.2 Kubernetes 環境

#### 方法一：使用 kubectl exec

```bash
# 1. 確認 Pod 名稱
kubectl get pods -l app=nextcloud

# 2. 將 mounts.json 複製到 Pod
kubectl cp mounts.json <namespace>/<pod-name>:/tmp/mounts.json

# 3. 執行 import（預覽模式）
kubectl exec -n <namespace> <pod-name> -u www-data -- \
  php occ files_external:import --dry /tmp/mounts.json

# 4. 正式匯入
kubectl exec -n <namespace> <pod-name> -u www-data -- \
  php occ files_external:import /tmp/mounts.json

# 5. 清理
kubectl exec -n <namespace> <pod-name> -- rm /tmp/mounts.json
```

#### 方法二：使用 ConfigMap + Job

建立一個 Kubernetes Job 來執行 import：

**1. 建立 ConfigMap（儲存 mounts.json）**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: external-storage-mounts
  namespace: nextcloud
data:
  mounts.json: |
    [
      {
        "mount_id": 1,
        "mount_point": "/minio-user00001",
        ...
      }
    ]
```

**2. 建立 Job**

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: import-external-storage
  namespace: nextcloud
spec:
  template:
    spec:
      containers:
      - name: nextcloud
        image: nextcloud:latest
        command: ["php", "occ", "files_external:import", "/config/mounts.json"]
        volumeMounts:
        - name: mounts-config
          mountPath: /config
          readOnly: true
        env:
        - name: NEXTCLOUD_ADMIN_USER
          value: "admin"
        - name: NEXTCLOUD_ADMIN_PASSWORD
          valueFrom:
            secretKeyRef:
              name: nextcloud-secrets
              key: admin-password
      volumes:
      - name: mounts-config
        configMap:
          name: external-storage-mounts
      restartPolicy: Never
```

**3. 執行 Job**

```bash
# 建立 ConfigMap
kubectl create configmap external-storage-mounts \
  --from-file=mounts.json=mounts.json \
  -n nextcloud

# 建立並執行 Job
kubectl apply -f import-job.yaml

# 查看 Job 狀態
kubectl get jobs -n nextcloud
kubectl logs -n nextcloud job/import-external-storage

# 清理 Job
kubectl delete job import-external-storage -n nextcloud
```

#### 方法三：使用 Init Container

在 Nextcloud Deployment 中加入 Init Container：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nextcloud
  namespace: nextcloud
spec:
  template:
    spec:
      initContainers:
      - name: import-external-storage
        image: nextcloud:latest
        command: ["php", "occ", "files_external:import", "/config/mounts.json"]
        volumeMounts:
        - name: mounts-config
          mountPath: /config
          readOnly: true
        env:
        - name: NEXTCLOUD_ADMIN_USER
          value: "admin"
        - name: NEXTCLOUD_ADMIN_PASSWORD
          valueFrom:
            secretKeyRef:
              name: nextcloud-secrets
              key: admin-password
      containers:
      - name: nextcloud
        image: nextcloud:latest
        volumeMounts:
        - name: mounts-config
          mountPath: /config
          readOnly: true
      volumes:
      - name: mounts-config
        configMap:
          name: external-storage-mounts
```

#### 方法四：使用 stdin（適合小檔案）

```bash
# 從本地檔案透過 stdin 傳入
cat mounts.json | kubectl exec -i -n <namespace> <pod-name> -u www-data -- \
  php occ files_external:import -
```

### 3.3 注意事項

#### 權限問題

- ✅ 必須使用 `www-data` 使用者執行（Docker）或 `-u www-data`（Kubernetes）
- ✅ 確保容器內有寫入 Nextcloud 資料目錄的權限

#### 檔案大小限制

- ⚠️ 如果 `mounts.json` 檔案很大（>10MB），建議使用 Volume Mount 或 ConfigMap
- ⚠️ Kubernetes ConfigMap 有 1MB 大小限制，超過需使用其他方式

#### 批次處理建議

對於 10,000 筆資料，建議：

1. **分批匯入**：將 JSON 分割成多個檔案（每批 1000-2000 筆）
2. **監控進度**：使用 `--dry` 先驗證格式
3. **錯誤處理**：檢查 exit code 和輸出訊息

```bash
# 分批匯入範例
for file in mounts_part*.json; do
    echo "處理 ${file}..."
    docker exec -u www-data nextcloud-container \
      php occ files_external:import "/tmp/${file}"
    if [ $? -eq 0 ]; then
        echo "✅ ${file} 匯入成功"
    else
        echo "❌ ${file} 匯入失敗"
        exit 1
    fi
done
```

---

## 總結

### 推薦工作流程

1. **產生 JSON**：使用 `generate_external_storage.py` 產生 `mounts.json`
2. **預覽驗證**：使用 `--dry` 模式驗證格式
3. **批次匯入**：在 Docker/K8s 環境執行 `php occ files_external:import`
4. **驗證結果**：檢查掛載點是否成功建立

### 快速參考

```bash
# 1. 產生 JSON
python generate_external_storage.py --csv users.csv -o mounts.json

# 2. Docker 環境匯入
docker cp mounts.json nextcloud:/tmp/
docker exec -u www-data nextcloud php occ files_external:import --dry /tmp/mounts.json
docker exec -u www-data nextcloud php occ files_external:import /tmp/mounts.json

# 3. Kubernetes 環境匯入
kubectl cp mounts.json nextcloud/nextcloud-pod:/tmp/
kubectl exec -n nextcloud nextcloud-pod -u www-data -- \
  php occ files_external:import /tmp/mounts.json
```

---

**最後更新：** 2026-01-26
