#!/bin/bash
# 更新 Docker 容器中的 StoragesController.php

set -e

# 設定
CONTAINER_NAME="${NC_CONTAINER:-nextcloud-app-1}"
SOURCE_FILE="StoragesController.php"
TARGET_PATH="/var/www/html/apps/files_external/lib/Controller/StoragesController.php"

# 顏色輸出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "=========================================="
echo "更新 Docker 容器中的程式碼"
echo "=========================================="
echo ""

# 檢查檔案是否存在
if [ ! -f "$SOURCE_FILE" ]; then
    echo -e "${RED}❌ 錯誤: 找不到來源檔案 $SOURCE_FILE${NC}"
    echo "請確認您在專案根目錄執行此腳本"
    exit 1
fi

# 檢查容器是否運行
if ! docker ps --format "{{.Names}}" | grep -q "^${CONTAINER_NAME}$"; then
    echo -e "${YELLOW}⚠ 警告: 容器 $CONTAINER_NAME 未運行${NC}"
    echo "正在搜尋其他 Nextcloud 容器..."
    
    # 嘗試找到其他 Nextcloud 容器
    OTHER_CONTAINER=$(docker ps --format "{{.Names}}" | grep -i nextcloud | head -n 1)
    if [ -n "$OTHER_CONTAINER" ]; then
        echo -e "${BLUE}找到容器: $OTHER_CONTAINER${NC}"
        read -p "是否使用此容器? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            CONTAINER_NAME="$OTHER_CONTAINER"
        else
            echo -e "${RED}請先啟動容器: docker-compose up -d${NC}"
            exit 1
        fi
    else
        echo -e "${RED}❌ 錯誤: 找不到運行中的 Nextcloud 容器${NC}"
        echo "請先啟動容器: docker-compose up -d"
        exit 1
    fi
fi

echo -e "${BLUE}使用容器: $CONTAINER_NAME${NC}"
echo ""

# 檢查目標路徑是否存在
if ! docker exec $CONTAINER_NAME test -f $TARGET_PATH; then
    echo -e "${RED}❌ 錯誤: 容器內找不到目標檔案 $TARGET_PATH${NC}"
    echo "請確認容器內的 Nextcloud 安裝路徑"
    exit 1
fi

echo -e "${YELLOW}1. 備份原始檔案...${NC}"
BACKUP_FILE="${TARGET_PATH}.backup.$(date +%Y%m%d_%H%M%S)"
docker exec $CONTAINER_NAME cp $TARGET_PATH $BACKUP_FILE 2>/dev/null || true
if docker exec $CONTAINER_NAME test -f $BACKUP_FILE; then
    echo -e "${GREEN}✓ 備份完成: $BACKUP_FILE${NC}"
else
    echo -e "${YELLOW}⚠ 備份失敗（可能權限問題），繼續執行...${NC}"
fi

echo ""
echo -e "${YELLOW}2. 複製檔案到容器...${NC}"
docker cp $SOURCE_FILE ${CONTAINER_NAME}:${TARGET_PATH}
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 檔案複製成功${NC}"
else
    echo -e "${RED}❌ 檔案複製失敗${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}3. 設定檔案權限...${NC}"
docker exec $CONTAINER_NAME chown www-data:www-data $TARGET_PATH 2>/dev/null || \
docker exec $CONTAINER_NAME chown 33:33 $TARGET_PATH 2>/dev/null || true
docker exec $CONTAINER_NAME chmod 644 $TARGET_PATH 2>/dev/null || true
echo -e "${GREEN}✓ 權限設定完成${NC}"

echo ""
echo -e "${YELLOW}4. 驗證檔案已更新...${NC}"
if docker exec $CONTAINER_NAME grep -q "記錄驗證失敗的詳細資訊" $TARGET_PATH 2>/dev/null; then
    echo -e "${GREEN}✓ 檔案已成功更新（包含新的日誌記錄功能）${NC}"
else
    echo -e "${YELLOW}⚠ 警告: 無法驗證檔案內容（可能檔案已更新但驗證標記不存在）${NC}"
    echo "   建議手動檢查檔案內容"
fi

echo ""
echo -e "${YELLOW}5. 清除 OPcache（可選）...${NC}"
# 嘗試清除快取
docker exec $CONTAINER_NAME php occ files:scan --all > /dev/null 2>&1 || true
echo -e "${BLUE}提示: 如果修改未生效，請重啟容器: docker-compose restart nextcloud${NC}"

echo ""
echo "=========================================="
echo -e "${GREEN}完成！${NC}"
echo "=========================================="
echo ""
echo "後續步驟:"
echo "  1. 重啟容器（清除 OPcache）:"
echo -e "     ${BLUE}docker compose -f ~/nextcloud-docker-compose.yaml restart${NC}"
echo ""
echo "  2. 啟用除錯模式並測試:"
echo -e "     ${BLUE}./tools/enable_debug_and_test.sh${NC}"
echo ""
echo "  3. 查看日誌:"
echo -e "     ${BLUE}docker exec $CONTAINER_NAME tail -f /var/www/html/data/nextcloud.log${NC}"
echo ""
if [ -n "$BACKUP_FILE" ] && docker exec $CONTAINER_NAME test -f $BACKUP_FILE 2>/dev/null; then
    echo "備份檔案位置: $BACKUP_FILE"
    echo "恢復備份: docker exec $CONTAINER_NAME cp $BACKUP_FILE $TARGET_PATH"
fi
echo "=========================================="
