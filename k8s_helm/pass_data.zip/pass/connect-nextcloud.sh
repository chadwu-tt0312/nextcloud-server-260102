#!/bin/bash

# Nextcloud 連接指南腳本

set -e

echo "=========================================="
echo "Nextcloud 連接指南"
echo "=========================================="
echo ""

# 取得 Service 資訊
SERVICE_NAME=$(kubectl get svc -n default -l app.kubernetes.io/name=nextcloud -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "nextcloud")

if [ -z "$SERVICE_NAME" ]; then
    echo "❌ 找不到 Nextcloud Service"
    exit 1
fi

echo "Service 名稱: $SERVICE_NAME"
echo ""

# 取得 Service 類型
SERVICE_TYPE=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.type}')

echo "Service 類型: $SERVICE_TYPE"
echo ""

if [ "$SERVICE_TYPE" = "NodePort" ]; then
    # NodePort 方式
    NODE_PORT=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.ports[0].nodePort}')
    SERVICE_PORT=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.ports[0].port}')
    
    echo "📌 NodePort 連接方式："
    echo "---------------------------------------------------"
    echo "NodePort: $NODE_PORT"
    echo "Service Port: $SERVICE_PORT"
    echo ""
    
    # 取得節點 IP
    NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null || \
              kubectl get nodes -o jsonpath='{.items[0].status.addresses[0].address}' 2>/dev/null || \
              echo "localhost")
    
    echo "節點 IP: $NODE_IP"
    echo ""
    echo "✅ 訪問方式："
    echo "   http://$NODE_IP:$NODE_PORT"
    echo ""
    
    # 檢查是否為 localhost
    if [ "$NODE_IP" != "localhost" ] && [ "$NODE_IP" != "127.0.0.1" ]; then
        echo "或使用 localhost（如果在同一台機器上）："
        echo "   http://localhost:$NODE_PORT"
        echo ""
    fi
    
elif [ "$SERVICE_TYPE" = "LoadBalancer" ]; then
    # LoadBalancer 方式
    EXTERNAL_IP=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || \
                  kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || \
                  echo "pending")
    
    SERVICE_PORT=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.ports[0].port}')
    
    echo "📌 LoadBalancer 連接方式："
    echo "---------------------------------------------------"
    echo "External IP: $EXTERNAL_IP"
    echo "Service Port: $SERVICE_PORT"
    echo ""
    
    if [ "$EXTERNAL_IP" != "pending" ]; then
        echo "✅ 訪問方式："
        echo "   http://$EXTERNAL_IP:$SERVICE_PORT"
        echo ""
    else
        echo "⚠️  LoadBalancer IP 尚未分配，請稍候..."
        echo "   使用以下命令監控："
        echo "   kubectl get svc $SERVICE_NAME -n default -w"
        echo ""
    fi
    
elif [ "$SERVICE_TYPE" = "ClusterIP" ]; then
    # ClusterIP 方式，需要使用 port-forward
    SERVICE_PORT=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.ports[0].port}')
    TARGET_PORT=$(kubectl get svc "$SERVICE_NAME" -n default -o jsonpath='{.spec.ports[0].targetPort}')
    
    echo "📌 ClusterIP 連接方式（需要 port-forward）："
    echo "---------------------------------------------------"
    echo "Service Port: $SERVICE_PORT"
    echo "Target Port: $TARGET_PORT"
    echo ""
    echo "✅ 執行以下命令開啟 port-forward："
    echo "   kubectl port-forward -n default svc/$SERVICE_NAME 8080:$SERVICE_PORT"
    echo ""
    echo "然後在瀏覽器訪問："
    echo "   http://localhost:8080"
    echo ""
    echo "或使用背景執行："
    echo "   kubectl port-forward -n default svc/$SERVICE_NAME 8080:$SERVICE_PORT &"
    echo ""
fi

# 檢查 Ingress
INGRESS_NAME=$(kubectl get ingress -n default -l app.kubernetes.io/name=nextcloud -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

if [ -n "$INGRESS_NAME" ]; then
    INGRESS_HOST=$(kubectl get ingress "$INGRESS_NAME" -n default -o jsonpath='{.spec.rules[0].host}' 2>/dev/null || echo "")
    INGRESS_PATH=$(kubectl get ingress "$INGRESS_NAME" -n default -o jsonpath='{.spec.rules[0].http.paths[0].path}' 2>/dev/null || echo "/")
    
    if [ -n "$INGRESS_HOST" ]; then
        echo "=========================================="
        echo "Ingress 連接方式"
        echo "=========================================="
        echo ""
        echo "Ingress 名稱: $INGRESS_NAME"
        echo "Host: $INGRESS_HOST"
        echo "Path: $INGRESS_PATH"
        echo ""
        
        # 檢查 TLS
        TLS_SECRET=$(kubectl get ingress "$INGRESS_NAME" -n default -o jsonpath='{.spec.tls[0].secretName}' 2>/dev/null || echo "")
        
        if [ -n "$TLS_SECRET" ]; then
            echo "✅ 使用 HTTPS 訪問："
            echo "   https://$INGRESS_HOST$INGRESS_PATH"
        else
            echo "✅ 使用 HTTP 訪問："
            echo "   http://$INGRESS_HOST$INGRESS_PATH"
        fi
        echo ""
    fi
fi

# 取得登入憑證
echo "=========================================="
echo "登入憑證"
echo "=========================================="
echo ""

SECRET_NAME=$(kubectl get secret -n default -l app.kubernetes.io/name=nextcloud -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "nextcloud")

if [ -n "$SECRET_NAME" ]; then
    USERNAME=$(kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.nextcloud-username}' 2>/dev/null | base64 -d 2>/dev/null || \
              kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.nextcloud-username}' 2>/dev/null | base64 -D 2>/dev/null || \
              echo "")
    
    PASSWORD=$(kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.nextcloud-password}' 2>/dev/null | base64 -d 2>/dev/null || \
              kubectl get secret "$SECRET_NAME" -n default -o jsonpath='{.data.nextcloud-password}' 2>/dev/null | base64 -D 2>/dev/null || \
              echo "")
    
    if [ -n "$USERNAME" ] && [ -n "$PASSWORD" ]; then
        echo "Username: $USERNAME"
        echo "Password: $PASSWORD"
        echo ""
    else
        echo "⚠️  無法從 secret 取得憑證"
        echo "   請檢查 secret: $SECRET_NAME"
        echo ""
    fi
else
    echo "⚠️  找不到 Nextcloud secret"
    echo ""
fi

# 取得 Pod 資訊
echo "=========================================="
echo "Pod 狀態"
echo "=========================================="
echo ""

POD_NAME=$(kubectl get pod -n default -l app.kubernetes.io/name=nextcloud -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

if [ -n "$POD_NAME" ]; then
    POD_STATUS=$(kubectl get pod "$POD_NAME" -n default -o jsonpath='{.status.phase}' 2>/dev/null || echo "Unknown")
    POD_READY=$(kubectl get pod "$POD_NAME" -n default -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "Unknown")
    
    echo "Pod 名稱: $POD_NAME"
    echo "狀態: $POD_STATUS"
    echo "Ready: $POD_READY"
    echo ""
    
    if [ "$POD_READY" != "True" ]; then
        echo "⚠️  Pod 尚未就緒，請檢查："
        echo "   kubectl describe pod $POD_NAME -n default"
        echo "   kubectl logs $POD_NAME -n default"
        echo ""
    fi
fi

# 顯示 Trusted Domains
echo "=========================================="
echo "Trusted Domains"
echo "=========================================="
echo ""

TRUSTED_DOMAINS=$(kubectl get pod "$POD_NAME" -n default -o jsonpath='{.spec.containers[0].env[?(@.name=="NEXTCLOUD_TRUSTED_DOMAINS")].value}' 2>/dev/null || echo "")

if [ -n "$TRUSTED_DOMAINS" ]; then
    echo "NEXTCLOUD_TRUSTED_DOMAINS: $TRUSTED_DOMAINS"
    echo ""
    echo "⚠️  注意：如果使用域名訪問，請確保域名在 Trusted Domains 列表中"
    echo ""
fi

echo "=========================================="
echo "快速連接命令"
echo "=========================================="
echo ""

if [ "$SERVICE_TYPE" = "NodePort" ]; then
    echo "# 直接訪問（如果在同一網路）"
    echo "open http://$NODE_IP:$NODE_PORT"
    echo ""
    echo "# 或使用 curl 測試"
    echo "curl http://$NODE_IP:$NODE_PORT"
    echo ""
elif [ "$SERVICE_TYPE" = "ClusterIP" ]; then
    echo "# 開啟 port-forward（前景執行）"
    echo "kubectl port-forward -n default svc/$SERVICE_NAME 8080:$SERVICE_PORT"
    echo ""
    echo "# 開啟 port-forward（背景執行）"
    echo "kubectl port-forward -n default svc/$SERVICE_NAME 8080:$SERVICE_PORT &"
    echo ""
    echo "# 測試連接"
    echo "curl http://localhost:8080"
    echo ""
fi
