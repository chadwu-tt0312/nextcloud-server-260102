# Nextcloud 除錯日誌啟用指南

## 方法一：使用 OCC 命令（推薦）

### 啟用除錯模式

```bash
# 在 Docker 容器中執行
docker exec <container_name> php occ log:manage --level=debug

# 在 Kubernetes Pod 中執行
kubectl exec -it <pod_name> -- php occ log:manage --level=debug

# 本地執行
php occ log:manage --level=debug
```

### 查看當前日誌設定

```bash
php occ log:manage
```

**輸出範例:**
```
Enabled logging backend: file
Log level: Debug (0)
Log timezone: UTC
```

### 日誌級別說明

| 級別 | 數值 | 說明 |
|------|------|------|
| `debug` | 0 | 最詳細，包含所有除錯資訊 |
| `info` | 1 | 一般資訊 |
| `warning` | 2 | 警告（預設） |
| `error` | 3 | 錯誤 |
| `fatal` | 4 | 嚴重錯誤 |

---

## 方法二：修改 config.php

### 1. 找到 config.php 檔案

通常位於 Nextcloud 根目錄：
- Docker: `/var/www/html/config/config.php`
- 本地: `./config/config.php`

### 2. 編輯 config.php

在 `$CONFIG` 陣列中加入或修改以下設定：

```php
<?php
$CONFIG = [
    // ... 其他設定 ...
    
    // 啟用除錯模式
    'debug' => true,
    
    // 設定日誌級別為 Debug (0)
    'loglevel' => 0,
    
    // 日誌檔案位置（可選，預設在 datadirectory）
    'logfile' => '/var/log/nextcloud.log',
    
    // 日誌類型（可選，預設為 'file'）
    'log_type' => 'file',
];
```

### 3. 重新載入配置

修改後，Nextcloud 會自動重新載入配置（無需重啟）。

---

## 方法三：臨時啟用（僅限 CLI）

在執行 `occ` 命令時啟用除錯輸出：

```bash
# 啟用除錯輸出到 STDOUT
php occ <command> --debug-log

# 指定除錯級別
php occ <command> --debug-log-level=0
```

---

## 查看日誌檔案

### 1. 找到日誌檔案位置

```bash
# 查看日誌檔案位置
php occ config:system:get logfile

# 預設位置（如果未設定）
# datadirectory/nextcloud.log
```

### 2. 查看即時日誌

```bash
# Docker
docker exec -it <container_name> tail -f /var/www/html/data/nextcloud.log

# Kubernetes
kubectl exec -it <pod_name> -- tail -f /var/www/html/data/nextcloud.log

# 本地
tail -f /path/to/nextcloud.log
```

### 3. 過濾 files_external 相關日誌

```bash
# 查看 files_external 相關的日誌
tail -f nextcloud.log | grep -i "files_external"

# 或使用更詳細的過濾
tail -f nextcloud.log | grep -E "(files_external|External Storage|validateStorage|backend parameters)"
```

---

## 針對 External Storage API 的除錯

### 1. 啟用除錯模式後，執行 API 請求

```bash
# 執行您的 curl 命令
curl -X POST "http://localhost:8085/apps/files_external/globalstorages" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{...}'
```

### 2. 立即查看日誌

```bash
# 查看最新的日誌（最後 50 行）
tail -n 50 nextcloud.log

# 或即時監控
tail -f nextcloud.log
```

### 3. 搜尋特定錯誤

```bash
# 搜尋 "Unsatisfied backend parameters" 相關日誌
grep -A 10 -B 10 "Unsatisfied backend parameters" nextcloud.log

# 搜尋 validateStorage 相關日誌
grep -A 5 "validateStorage" nextcloud.log
```

---

## 進階除錯設定

### 啟用 Backtrace（堆疊追蹤）

在 `config.php` 中加入：

```php
$CONFIG = [
    // ... 其他設定 ...
    'log.backtrace' => true,  // 啟用堆疊追蹤
    'loglevel' => 0,  // Debug 級別
];
```

這會在日誌中包含完整的函數呼叫堆疊，有助於追蹤問題。

### 啟用資料庫查詢日誌

```php
$CONFIG = [
    // ... 其他設定 ...
    'db.log_request_id' => true,  // 記錄請求 ID 到資料庫日誌
];
```

---

## 除錯腳本範例

建立一個腳本來啟用除錯並執行測試：

```bash
#!/bin/bash
# enable_debug_and_test.sh

CONTAINER_NAME="nextcloud-app-1"  # 或您的容器名稱

echo "1. 啟用除錯模式..."
docker exec $CONTAINER_NAME php occ log:manage --level=debug

echo ""
echo "2. 查看當前日誌設定..."
docker exec $CONTAINER_NAME php occ log:manage

echo ""
echo "3. 執行 API 測試..."
# 您的 curl 命令
curl -X POST "http://localhost:8085/apps/files_external/globalstorages" \
  -u "admin:password123" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-DEPT_SMG_ARC1",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "dep-smg-arc1-filespace",
      "use_path_style": true,
      "key": "ZEPNGTC059NIHD4KHYVW",
      "secret": "xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": [],
    "priority": 100
  }'

echo ""
echo "4. 查看最新日誌（最後 100 行）..."
docker exec $CONTAINER_NAME tail -n 100 /var/www/html/data/nextcloud.log | grep -E "(files_external|validateStorage|backend|error|debug)" -A 5 -B 5
```

---

## 日誌格式說明

Nextcloud 日誌格式通常如下：

```
[日期時間] [級別] [應用程式] 訊息內容
```

**範例:**
```
[2026-01-26T16:30:45+00:00] [debug] [files_external] Validating storage parameters...
[2026-01-26T16:30:45+00:00] [error] [files_external] Unsatisfied backend parameters
```

---

## 注意事項

1. **效能影響:** 啟用 Debug 級別會產生大量日誌，可能影響效能，建議只在除錯時使用
2. **日誌檔案大小:** Debug 模式會快速增加日誌檔案大小，請定期清理或輪轉日誌
3. **安全性:** 除錯日誌可能包含敏感資訊（如密碼、金鑰），請妥善保管
4. **生產環境:** 除錯完成後，記得將日誌級別改回 `warning` (2)

---

## 恢復正常日誌級別

```bash
# 使用 OCC 命令
php occ log:manage --level=warning

# 或修改 config.php
'loglevel' => 2,  // Warning
'debug' => false,
```

---

## 相關檔案位置

- **日誌設定命令:** `core/Command/Log/Manage.php`
- **日誌實作:** `lib/private/Log.php`
- **config.php 範例:** `config/config.sample.php`
- **External Storage 控制器:** `apps/files_external/lib/Controller/StoragesController.php`
