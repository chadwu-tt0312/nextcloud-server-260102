# 更新 Docker 容器中的程式碼

## 方法一：直接複製檔案到運行中的容器（最簡單，臨時方案）

### 適用場景
- 快速測試修改
- 臨時除錯
- 不需要持久化修改

### 步驟

#### 1. 確認容器名稱

```bash
# 查看運行中的 Nextcloud 容器
docker ps | grep nextcloud

# 或使用容器 ID
docker ps
```

#### 2. 複製檔案到容器

```bash
# 方法 A: 使用容器名稱（推薦）
CONTAINER_NAME="chad-nextcloud-1"  # 替換為您的容器名稱
docker cp apps/files_external/lib/Controller/StoragesController.php \
  ${CONTAINER_NAME}:/var/www/html/apps/files_external/lib/Controller/StoragesController.php

# 方法 B: 使用容器 ID
CONTAINER_ID=$(docker ps | grep nextcloud | awk '{print $1}')
docker cp apps/files_external/lib/Controller/StoragesController.php \
  ${CONTAINER_ID}:/var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

#### 3. 驗證檔案已更新

```bash
# 檢查檔案內容
docker exec ${CONTAINER_NAME} grep -A 5 "記錄驗證失敗的詳細資訊" \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php

# 或查看檔案修改時間
docker exec ${CONTAINER_NAME} ls -lh \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

#### 4. 清除 PHP OPcache（如果需要）

```bash
# Nextcloud 通常會自動清除，但如果有快取問題可以手動清除
docker exec ${CONTAINER_NAME} php occ files:scan --all
```

---

## 方法二：使用 Bind Mount（開發環境推薦）

### 適用場景
- 開發環境
- 需要頻繁修改程式碼
- 修改需要持久化

### 步驟

#### 1. 修改 docker-compose.yml

如果您的 `docker-compose.yml` 使用 **named volume**（如 `nextcloud:/var/www/html`），需要改為 **bind mount**：

**修改前:**
```yaml
volumes:
  - nextcloud:/var/www/html
```

**修改後:**
```yaml
volumes:
  - ./:/var/www/html  # 將整個專案目錄掛載到容器
  # 或只掛載 apps 目錄
  # - ./apps:/var/www/html/apps
```

**完整範例（docker-compose.yml）:**
```yaml
version: "3.7"
services:
  nextcloud:
    image: nextcloud:32
    restart: always
    ports:
      - "8085:80"
    volumes:
      # 掛載整個專案目錄（開發環境）
      - ./:/var/www/html
      # 或只掛載需要修改的部分
      # - ./apps:/var/www/html/apps
      # - ./config:/var/www/html/config
    environment:
      - MYSQL_HOST=nextcloud-db
      - MYSQL_DATABASE=nextcloud
      - MYSQL_USER=nextcloud
      - MYSQL_PASSWORD=upspi
```

#### 2. 重新啟動容器

```bash
# 停止容器
docker-compose down

# 重新啟動（使用新的 volume 設定）
docker-compose up -d

# 或只重啟 nextcloud 服務
docker-compose restart nextcloud
```

#### 3. 驗證

修改本地檔案後，容器內的檔案會自動同步（無需重啟容器）。

---

## 方法三：使用 Named Volume（需要進入容器）

### 適用場景
- 生產環境（不建議直接修改）
- 使用 named volume 的部署

### 步驟

#### 1. 進入容器

```bash
CONTAINER_NAME="chad-nextcloud-1"
docker exec -it ${CONTAINER_NAME} /bin/bash
```

#### 2. 在容器內編輯檔案

```bash
# 安裝編輯器（如果沒有）
apt-get update && apt-get install -y vim nano

# 編輯檔案
vi /var/www/html/apps/files_external/lib/Controller/StoragesController.php
# 或
nano /var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

#### 3. 或使用 docker cp 複製檔案

```bash
# 從容器複製出來（備份）
docker cp ${CONTAINER_NAME}:/var/www/html/apps/files_external/lib/Controller/StoragesController.php \
  ./StoragesController.php.backup

# 修改本地檔案後，複製回去
docker cp ./apps/files_external/lib/Controller/StoragesController.php \
  ${CONTAINER_NAME}:/var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

---

## 方法四：重新構建 Docker Image（生產環境推薦）

### 適用場景
- 生產環境
- 需要版本控制
- 需要部署到多個環境

### 步驟

#### 1. 建立 Dockerfile

建立 `Dockerfile.custom`：

```dockerfile
FROM nextcloud:32

# 複製修改後的檔案
COPY apps/files_external/lib/Controller/StoragesController.php \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php

# 確保檔案權限正確
RUN chown -R www-data:www-data /var/www/html/apps/files_external
```

#### 2. 構建自訂 Image

```bash
docker build -f Dockerfile.custom -t nextcloud-custom:latest .
```

#### 3. 修改 docker-compose.yml

```yaml
services:
  nextcloud:
    image: nextcloud-custom:latest  # 使用自訂 image
    # ... 其他設定 ...
```

#### 4. 重新啟動

```bash
docker-compose down
docker-compose up -d
```

---

## 方法五：使用自動化腳本（推薦）

建立一個腳本自動化整個過程：

### 腳本：`tools/update_docker_code.sh`

```bash
#!/bin/bash
# 更新 Docker 容器中的 StoragesController.php

set -e

# 設定
CONTAINER_NAME="${NC_CONTAINER:-chad-nextcloud-1}"
SOURCE_FILE="apps/files_external/lib/Controller/StoragesController.php"
TARGET_PATH="/var/www/html/apps/files_external/lib/Controller/StoragesController.php"

# 顏色輸出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "=========================================="
echo "更新 Docker 容器中的程式碼"
echo "=========================================="
echo ""

# 檢查檔案是否存在
if [ ! -f "$SOURCE_FILE" ]; then
    echo -e "${RED}❌ 錯誤: 找不到來源檔案 $SOURCE_FILE${NC}"
    exit 1
fi

# 檢查容器是否運行
if ! docker ps | grep -q "$CONTAINER_NAME"; then
    echo -e "${RED}❌ 錯誤: 容器 $CONTAINER_NAME 未運行${NC}"
    echo "請先啟動容器: docker-compose up -d"
    exit 1
fi

echo -e "${YELLOW}1. 備份原始檔案...${NC}"
docker exec $CONTAINER_NAME cp $TARGET_PATH ${TARGET_PATH}.backup.$(date +%Y%m%d_%H%M%S) || true

echo -e "${YELLOW}2. 複製檔案到容器...${NC}"
docker cp $SOURCE_FILE ${CONTAINER_NAME}:${TARGET_PATH}

echo -e "${YELLOW}3. 設定檔案權限...${NC}"
docker exec $CONTAINER_NAME chown www-data:www-data $TARGET_PATH
docker exec $CONTAINER_NAME chmod 644 $TARGET_PATH

echo -e "${YELLOW}4. 驗證檔案已更新...${NC}"
if docker exec $CONTAINER_NAME grep -q "記錄驗證失敗的詳細資訊" $TARGET_PATH; then
    echo -e "${GREEN}✓ 檔案已成功更新${NC}"
else
    echo -e "${RED}❌ 警告: 檔案可能未正確更新${NC}"
fi

echo ""
echo -e "${YELLOW}5. 清除 OPcache（可選）...${NC}"
docker exec $CONTAINER_NAME php occ files:scan --all > /dev/null 2>&1 || true

echo ""
echo "=========================================="
echo -e "${GREEN}完成！${NC}"
echo "=========================================="
echo ""
echo "提示:"
echo "  - 備份檔案位置: ${TARGET_PATH}.backup.*"
echo "  - 查看日誌: docker exec $CONTAINER_NAME tail -f /var/www/html/data/nextcloud.log"
echo ""
```

### 使用腳本

```bash
# 賦予執行權限
chmod +x tools/update_docker_code.sh

# 執行
./tools/update_docker_code.sh

# 或指定容器名稱
NC_CONTAINER="nextcloud" ./tools/update_docker_code.sh
```

---

## 驗證修改是否生效

### 1. 檢查檔案內容

```bash
docker exec ${CONTAINER_NAME} grep -A 10 "記錄驗證失敗的詳細資訊" \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

### 2. 執行 API 測試

```bash
# 使用之前建立的測試腳本
./tools/enable_debug_and_test.sh
```

### 3. 查看日誌

```bash
# 查看是否有新的日誌記錄
docker exec ${CONTAINER_NAME} tail -n 50 /var/www/html/data/nextcloud.log | \
  grep -E "(validation|Parameter|backend)" -A 2 -B 2
```

---

## 注意事項

### 1. 檔案權限

確保檔案權限正確：
```bash
docker exec ${CONTAINER_NAME} chown www-data:www-data \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php
docker exec ${CONTAINER_NAME} chmod 644 \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php
```

### 2. PHP OPcache

Nextcloud 使用 OPcache 快取 PHP 檔案。修改後可能需要：
- 等待快取過期（通常幾分鐘）
- 重啟容器：`docker-compose restart nextcloud`
- 或清除快取：`docker exec ${CONTAINER_NAME} php occ files:scan --all`

### 3. 備份

修改前務必備份：
```bash
docker exec ${CONTAINER_NAME} cp \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php.backup
```

### 4. 版本控制

如果使用 Git，建議：
- 先提交修改到本地分支
- 再更新到容器
- 避免在容器內直接修改（會丟失修改）

---

## 快速參考

### 最常用的命令

```bash
# 1. 複製檔案到容器
docker cp apps/files_external/lib/Controller/StoragesController.php \
  chad-nextcloud-1:/var/www/html/apps/files_external/lib/Controller/StoragesController.php

# 2. 設定權限
docker exec chad-nextcloud-1 chown www-data:www-data \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php

# 3. 重啟容器（清除 OPcache）
docker-compose restart nextcloud

# 4. 查看日誌
docker exec chad-nextcloud-1 tail -f /var/www/html/data/nextcloud.log
```

---

## 故障排除

### 問題 1: 修改後沒有生效

**解決方案:**
```bash
# 1. 重啟容器
docker-compose restart nextcloud

# 2. 清除 OPcache
docker exec chad-nextcloud-1 php occ files:scan --all

# 3. 檢查檔案是否真的更新了
docker exec chad-nextcloud-1 cat \
  /var/www/html/apps/files_external/lib/Controller/StoragesController.php | \
  grep "記錄驗證失敗"
```

### 問題 2: 權限錯誤

**解決方案:**
```bash
docker exec chad-nextcloud-1 chown -R www-data:www-data \
  /var/www/html/apps/files_external
```

### 問題 3: 容器找不到

**解決方案:**
```bash
# 列出所有容器
docker ps -a

# 找到正確的容器名稱或 ID
docker ps | grep nextcloud
```

---

## 相關檔案

- **修改的檔案:** `apps/files_external/lib/Controller/StoragesController.php`
- **Docker Compose 檔案:** `docker/nextcloud-docker-compose.yaml`
- **自動化腳本:** `tools/update_docker_code.sh`（需要建立）
