# legacy_auth 和 useMultipartCopy 參數分析

## 程式碼位置

### 1. 參數定義位置

**檔案:** `apps/files_external/lib/Lib/Backend/AmazonS3.php`

```php
// 第 40-41 行
(new DefinitionParameter('legacy_auth', $l->t('Legacy (v2) authentication')))
    ->setType(DefinitionParameter::VALUE_BOOLEAN),
    // ❌ 沒有 ->setFlag(DefinitionParameter::FLAG_OPTIONAL)
    // ❌ 沒有 ->setDefaultValue()

// 第 42-44 行
(new DefinitionParameter('useMultipartCopy', $l->t('Enable multipart copy')))
    ->setType(DefinitionParameter::VALUE_BOOLEAN)
    ->setDefaultValue(true),
    // ❌ 沒有 ->setFlag(DefinitionParameter::FLAG_OPTIONAL)
    // ✅ 有 ->setDefaultValue(true)
```

---

## 為什麼被視為「必填」？

### 關鍵程式碼：`isOptional()` 方法

**檔案:** `apps/files_external/lib/Lib/DefinitionParameter.php:182-184`

```php
public function isOptional(): bool {
    return $this->isFlagSet(self::FLAG_OPTIONAL) || $this->isFlagSet(self::FLAG_USER_PROVIDED);
}
```

**判斷標準:**
- 只有當參數有 `FLAG_OPTIONAL` 或 `FLAG_USER_PROVIDED` 標記時，`isOptional()` 才返回 `true`
- **`legacy_auth` 和 `useMultipartCopy` 都沒有 `FLAG_OPTIONAL` 標記**
- 因此 `isOptional()` 返回 `false` → **被視為「必填」**

---

## 驗證邏輯

### 驗證流程

**檔案:** `apps/files_external/lib/Lib/FrontendDefinitionTrait.php:95-106`

```php
public function validateStorageDefinition(StorageConfig $storage): bool {
    foreach ($this->getParameters() as $name => $parameter) {
        $value = $storage->getBackendOption($name);
        
        // ⚠️ 關鍵邏輯：如果值不是 null，或者參數不是可選的，就需要驗證
        if (!is_null($value) || !$parameter->isOptional()) {
            if (!$parameter->validateValue($value)) {
                return false;  // ← 驗證失敗
            }
            $storage->setBackendOption($name, $value);
        }
    }
    return true;
}
```

**邏輯分析:**
- `!is_null($value) || !$parameter->isOptional()`
- 如果參數不是可選的（`!$parameter->isOptional()` 為 `true`），即使值為 `null`，也會進入驗證流程
- 當值為 `null` 時，會調用 `validateValue(null)`

### BOOLEAN 參數驗證

**檔案:** `apps/files_external/lib/Lib/DefinitionParameter.php:193-216`

```php
public function validateValue(&$value): bool {
    switch ($this->getType()) {
        case self::VALUE_BOOLEAN:
            if (!is_bool($value)) {
                switch ($value) {
                    case 'true':
                        $value = true;
                        break;
                    case 'false':
                        $value = false;
                        break;
                    default:
                        return false;  // ← null 會走到這裡，返回 false
                }
            }
            break;
        default:
            if (!$value && !$this->isOptional()) {
                return false;
            }
            break;
    }
    return true;
}
```

**問題:**
- 當值為 `null` 時，`!is_bool(null)` 為 `true`
- `null` 不在 `'true'` 或 `'false'` 的 case 中
- 走到 `default` 分支，返回 `false` → **驗證失敗**

---

## 問題根源

### 1. `legacy_auth` 參數

**定義:**
- ❌ 沒有 `FLAG_OPTIONAL` → `isOptional()` 返回 `false`
- ❌ 沒有 `setDefaultValue()` → 無預設值
- **結論:** 根據現有程式碼邏輯，這是**必填參數**

**但這可能是 Nextcloud 的 Bug：**
- 如果這個參數應該有預設值（例如 `false`），應該在定義時加上 `->setDefaultValue(false)`
- 或者應該加上 `->setFlag(DefinitionParameter::FLAG_OPTIONAL)` 標記為可選

### 2. `useMultipartCopy` 參數

**定義:**
- ❌ 沒有 `FLAG_OPTIONAL` → `isOptional()` 返回 `false`
- ✅ 有 `setDefaultValue(true)` → 有預設值
- **結論:** 根據現有程式碼邏輯，這是**必填參數**

**這是 Nextcloud 的 Bug：**
- 雖然有預設值 `true`，但驗證邏輯**沒有在驗證前應用預設值**
- 當值為 `null` 時，驗證邏輯不會自動使用預設值，導致驗證失敗

---

## 驗證邏輯的缺陷

### 當前驗證邏輯的問題

在 `FrontendDefinitionTrait::validateStorageDefinition()` 中：

```php
// 當前邏輯（有缺陷）
if (!is_null($value) || !$parameter->isOptional()) {
    if (!$parameter->validateValue($value)) {  // ← 如果 value 是 null，這裡會失敗
        return false;
    }
}
```

**問題:**
- 當參數不是可選的且值為 `null` 時，會直接調用 `validateValue(null)`
- **沒有在驗證前檢查並應用預設值**
- 即使參數有 `setDefaultValue()`，也不會被使用

### 應該的邏輯（修復建議）

```php
// 修復後的邏輯
foreach ($this->getParameters() as $name => $parameter) {
    $value = $storage->getBackendOption($name);
    
    // ✅ 如果值為 null 且有預設值，使用預設值
    if (is_null($value) && !is_null($parameter->getDefaultValue())) {
        $value = $parameter->getDefaultValue();
        $storage->setBackendOption($name, $value);
    }
    
    // 然後再驗證
    if (!is_null($value) || !$parameter->isOptional()) {
        if (!$parameter->validateValue($value)) {
            return false;
        }
        $storage->setBackendOption($name, $value);
    }
}
```

---

## 結論

### 1. `legacy_auth` 參數

**根據程式碼定義:**
- **位置:** `apps/files_external/lib/Lib/Backend/AmazonS3.php:40-41`
- **狀態:** 沒有 `FLAG_OPTIONAL`，沒有 `setDefaultValue()` → **必填**
- **是否為 Bug:** 可能是，應該有預設值 `false` 或標記為可選

### 2. `useMultipartCopy` 參數

**根據程式碼定義:**
- **位置:** `apps/files_external/lib/Lib/Backend/AmazonS3.php:42-44`
- **狀態:** 沒有 `FLAG_OPTIONAL`，有 `setDefaultValue(true)` → **必填（但這是 Bug）**
- **是否為 Bug:** **是**，驗證邏輯沒有應用預設值

### 3. 驗證邏輯的 Bug

**位置:** `apps/files_external/lib/Lib/FrontendDefinitionTrait.php:95-106`

**問題:** 驗證邏輯沒有在驗證前應用預設值，導致即使參數有預設值，當值為 `null` 時也會驗證失敗。

---

## 解決方案

### 方案一：在 API 請求中明確提供參數（臨時解決方案）

```json
{
  "backendOptions": {
    "legacy_auth": false,
    "useMultipartCopy": true
  }
}
```

### 方案二：修復 Nextcloud 驗證邏輯（長期解決方案）

修改 `FrontendDefinitionTrait::validateStorageDefinition()` 以支援預設值自動應用。

### 方案三：修復參數定義（如果這是 Nextcloud 的設計缺陷）

- 為 `legacy_auth` 添加 `->setDefaultValue(false)`
- 為 `useMultipartCopy` 添加 `->setFlag(DefinitionParameter::FLAG_OPTIONAL)` 或修復驗證邏輯

---

## 相關檔案

1. **參數定義:** `apps/files_external/lib/Lib/Backend/AmazonS3.php`
2. **參數類別:** `apps/files_external/lib/Lib/DefinitionParameter.php`
3. **驗證邏輯:** `apps/files_external/lib/Lib/FrontendDefinitionTrait.php`
