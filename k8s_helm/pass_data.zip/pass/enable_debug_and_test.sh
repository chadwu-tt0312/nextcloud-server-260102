#!/bin/bash
# 啟用 Nextcloud 除錯模式並執行 API 測試

# 設定
CONTAINER_NAME="${NC_CONTAINER:-chad-nextcloud-1}"  # 可透過環境變數覆蓋
NEXTCLOUD_URL="http://localhost:8085"
ADMIN_USER="admin"
ADMIN_PASS="password123"

# 顏色輸出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=========================================="
echo "Nextcloud 除錯模式啟用與 API 測試"
echo "=========================================="
echo ""

# 檢查是否在 Docker 環境
if command -v docker &> /dev/null; then
    USE_DOCKER=true
    echo -e "${GREEN}✓${NC} 偵測到 Docker 環境"
    echo "容器名稱: $CONTAINER_NAME"
else
    USE_DOCKER=false
    echo -e "${YELLOW}⚠${NC} 未偵測到 Docker，使用本地 PHP"
fi

echo ""
echo "1. 啟用除錯模式..."
if [ "$USE_DOCKER" = true ]; then
    docker exec $CONTAINER_NAME php occ log:manage --level=debug
else
    php occ log:manage --level=debug
fi

echo ""
echo "2. 查看當前日誌設定..."
if [ "$USE_DOCKER" = true ]; then
    docker exec $CONTAINER_NAME php occ log:manage
    LOG_FILE=$(docker exec $CONTAINER_NAME php occ config:system:get logfile 2>/dev/null || echo "/var/www/html/data/nextcloud.log")
else
    php occ log:manage
    LOG_FILE=$(php occ config:system:get logfile 2>/dev/null || echo "./data/nextcloud.log")
fi

echo ""
echo "日誌檔案位置: $LOG_FILE"
echo ""

echo "3. 執行 API 測試..."
echo "----------------------------------------"
RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" -X POST "${NEXTCLOUD_URL}/apps/files_external/globalstorages" \
  -u "${ADMIN_USER}:${ADMIN_PASS}" \
  -H "OCS-APIRequest: true" \
  -H "Content-Type: application/json" \
  -d '{
    "mountPoint": "/minio-DEPT_SMG_ARC1",
    "backend": "amazons3",
    "authMechanism": "amazons3::accesskey",
    "backendOptions": {
      "bucket": "dep-smg-arc1-filespace",
      "hostname": "192.168.31.180",
      "port": "9000",
      "region": "us-east-1",
      "use_ssl": false,
      "use_path_style": true,
      "key": "ZEPNGTC059NIHD4KHYVW",
      "secret": "xh3RYBfwY2wFhtX6o87Zw+vUTX+WjAEhuk+W3vdj"
    },
    "mountOptions": {},
    "applicableUsers": [],
    "applicableGroups": [],
    "priority": 100
  }')

HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
BODY=$(echo "$RESPONSE" | sed '/HTTP_CODE/d')

echo "HTTP Status: $HTTP_CODE"
echo "Response: $BODY"
echo ""

if [ "$HTTP_CODE" != "201" ] && [ "$HTTP_CODE" != "200" ]; then
    echo -e "${RED}❌ API 請求失敗${NC}"
    echo ""
    echo "4. 查看相關除錯日誌..."
    echo "----------------------------------------"
    
    if [ "$USE_DOCKER" = true ]; then
        echo "最後 50 行日誌（過濾 files_external 相關）:"
        docker exec $CONTAINER_NAME tail -n 50 "$LOG_FILE" 2>/dev/null | grep -E "(files_external|validateStorage|backend|Unsatisfied)" -i -A 3 -B 3 || \
        docker exec $CONTAINER_NAME tail -n 50 "$LOG_FILE" 2>/dev/null
    else
        echo "最後 50 行日誌（過濾 files_external 相關）:"
        tail -n 50 "$LOG_FILE" 2>/dev/null | grep -E "(files_external|validateStorage|backend|Unsatisfied)" -i -A 3 -B 3 || \
        tail -n 50 "$LOG_FILE" 2>/dev/null
    fi
else
    echo -e "${GREEN}✓ API 請求成功${NC}"
fi

echo ""
echo "=========================================="
echo "提示: 查看完整日誌:"
if [ "$USE_DOCKER" = true ]; then
    echo "  docker exec $CONTAINER_NAME tail -f $LOG_FILE"
else
    echo "  tail -f $LOG_FILE"
fi
echo ""
echo "恢復正常日誌級別:"
if [ "$USE_DOCKER" = true ]; then
    echo "  docker exec $CONTAINER_NAME php occ log:manage --level=warning"
else
    echo "  php occ log:manage --level=warning"
fi
echo "=========================================="
